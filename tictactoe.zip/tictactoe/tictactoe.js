// Game Variables
let currentPlayer = "X";
let gameActive = true;
let gameState = ["", "", "", "", "", "", "", "", ""];
let playerXScore = 0;
let playerOScore = 0;
let aiMode = false;

// Winning Combinations
const winningCombinations = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
];

// Elements
const modeSelection = document.getElementById("modeSelection");
const gameSection = document.getElementById("gameSection");
const board = document.getElementById("board");
const restartButton = document.getElementById("restart");
const resetScoresButton = document.getElementById("resetScores");
const playerXScoreElement = document.getElementById("playerXScore");
const playerOScoreElement = document.getElementById("playerOScore");
const aiModeButton = document.getElementById("aiMode");
const twoPlayerModeButton = document.getElementById("twoPlayerMode");
const modal = document.getElementById("modal");
const modalMessage = document.getElementById("modalMessage");
const closeModal = document.getElementById("closeModal");

// Show Modal
function showModal(message) {
    modalMessage.textContent = message;
    modal.classList.remove("hidden");
}

// Close Modal
closeModal.addEventListener("click", () => {
    modal.classList.add("hidden");
});

// Initialize Board
function initializeBoard() {
    board.innerHTML = "";
    gameState = ["", "", "", "", "", "", "", "", ""];
    gameActive = true;

    for (let i = 0; i < 9; i++) {
        const cell = document.createElement("div");
        cell.classList.add("cell");
        cell.setAttribute("data-index", i);

        cell.addEventListener("click", handleCellClick);

        board.appendChild(cell);
    }

    currentPlayer = "X";
}

// Handle Cell Click
function handleCellClick(event) {
    const cell = event.target;
    const cellIndex = cell.getAttribute("data-index");

    if (gameState[cellIndex] !== "" || !gameActive) return;

    gameState[cellIndex] = currentPlayer;
    cell.textContent = currentPlayer;
    cell.classList.add("taken");

    checkResult();

    if (gameActive) {
        if (aiMode && currentPlayer === "X") {
            currentPlayer = "O";
            setTimeout(aiMove, 500);
        } else {
            currentPlayer = currentPlayer === "X" ? "O" : "X";
        }
    }
}

// AI Move
function aiMove() {
    const availableCells = gameState
        .map((value, index) => (value === "" ? index : null))
        .filter((index) => index !== null);

    if (availableCells.length === 0) return;

    const randomIndex = availableCells[Math.floor(Math.random() * availableCells.length)];
    gameState[randomIndex] = currentPlayer;

    const cell = board.querySelector(`[data-index='${randomIndex}']`);
    cell.textContent = currentPlayer;
    cell.classList.add("taken");

    checkResult();

    if (gameActive) {
        currentPlayer = "X";
    }
}

// Check Result
function checkResult() {
    let roundWon = false;

    for (const combination of winningCombinations) {
        const [a, b, c] = combination;
        if (gameState[a] && gameState[a] === gameState[b] && gameState[a] === gameState[c]) {
            roundWon = true;
            break;
        }
    }

    if (roundWon) {
        gameActive = false;
        updateScore(currentPlayer);
        showModal(`Player ${currentPlayer} wins!`);
        return;
    }

    if (!gameState.includes("")) {
        gameActive = false;
        showModal("It's a draw!");
    }
}

// Update Score
function updateScore(winner) {
    if (winner === "X") {
        playerXScore++;
        playerXScoreElement.textContent = `Player X: ${playerXScore}`;
    } else {
        playerOScore++;
        playerOScoreElement.textContent = `Player O: ${playerOScore}`;
    }
}

// Start Game
function startGame(mode) {
    aiMode = mode === "AI";
    modeSelection.classList.add("hidden");
    gameSection.classList.remove("hidden");
    modal.classList.add("hidden"); // Ensure modal is hidden
    initializeBoard();
}

// Button Listeners
restartButton.addEventListener("click", initializeBoard);
resetScoresButton.addEventListener("click", () => {
    playerXScore = 0;
    playerOScore = 0;
    playerXScoreElement.textContent = "Player X: 0";
    playerOScoreElement.textContent = "Player O: 0";
    initializeBoard();
});
aiModeButton.addEventListener("click", () => startGame("AI"));
twoPlayerModeButton.addEventListener("click", () => startGame("TwoPlayer"));
